.\buzzer.o: buzzer.c
.\buzzer.o: C:\keli\ARM\Inc\Philips\lpc21xx.h
.\buzzer.o: defines.h
.\buzzer.o: declarations.h
.\buzzer.o: types.h
