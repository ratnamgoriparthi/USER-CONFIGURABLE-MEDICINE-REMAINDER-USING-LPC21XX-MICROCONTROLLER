.\kpm.o: kpm.c
.\kpm.o: C:\keli\ARM\Inc\Philips\lpc21xx.h
.\kpm.o: defines.h
.\kpm.o: declarations.h
.\kpm.o: types.h
.\kpm.o: types.h
