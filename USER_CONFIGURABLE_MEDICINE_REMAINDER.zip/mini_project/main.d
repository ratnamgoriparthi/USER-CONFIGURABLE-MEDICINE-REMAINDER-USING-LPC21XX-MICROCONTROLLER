.\main.o: main.c
.\main.o: C:\keli\ARM\Inc\Philips\lpc21xx.h
.\main.o: defines.h
.\main.o: declarations.h
.\main.o: types.h
.\main.o: types.h
