.\interrupts.o: interrupts.c
.\interrupts.o: C:\keli\ARM\Inc\Philips\lpc21xx.h
.\interrupts.o: defines.h
.\interrupts.o: declarations.h
.\interrupts.o: types.h
.\interrupts.o: types.h
