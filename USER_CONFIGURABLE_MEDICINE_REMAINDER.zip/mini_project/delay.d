.\delay.o: delay.c
.\delay.o: defines.h
.\delay.o: C:\keli\ARM\Inc\Philips\lpc21xx.h
