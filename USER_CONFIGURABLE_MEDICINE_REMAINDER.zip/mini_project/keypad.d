.\keypad.o: keypad.c
.\keypad.o: C:\keli\ARM\Inc\Philips\lpc21xx.h
.\keypad.o: defines.h
.\keypad.o: declarations.h
.\keypad.o: types.h
.\keypad.o: types.h
