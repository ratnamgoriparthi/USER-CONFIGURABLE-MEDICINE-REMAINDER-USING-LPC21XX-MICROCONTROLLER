.\lcd.o: lcd.c
.\lcd.o: C:\keli\ARM\Inc\Philips\lpc21xx.h
.\lcd.o: defines.h
.\lcd.o: declarations.h
.\lcd.o: types.h
