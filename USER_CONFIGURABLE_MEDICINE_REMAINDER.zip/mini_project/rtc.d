.\rtc.o: rtc.c
.\rtc.o: C:\keli\ARM\Inc\Philips\lpc21xx.h
.\rtc.o: types.h
.\rtc.o: defines.h
.\rtc.o: declarations.h
.\rtc.o: types.h
